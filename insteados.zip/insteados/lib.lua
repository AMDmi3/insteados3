require "sprites"

local old_title = instead.get_title;
instead.get_title = function()
  local r = old_title();
  r = string.gsub(r, "\n", "");
  return r.."\n\n\n";
end

function if_(cnd,x,y)
  return function(s)
    if apply(cnd,s) then
      return x;
    else
      return y;
    end
  end
end

local old_room = room;
function room(r)
  return old_room(r);
end

game.pic = 
function()
  local s = here();
  if s.pxa == nil then
    return;
  end
  local pxa = tc(s.pxa,s);
  if pxa == nil then
    return;
  end
  if game.cache == nil then
    game.cache = sprite.load("gfx/pic.png");
  else
    local pt = sprite.blank(500, 200);
    sprite.copy(pt, game.cache, 0, 0);
    sprite.free(pt);
  end
  for _,v in ipairs(pxa) do
    local vv = tc(v[1],s);
    if vv ~= nil then
      local spr = sprite.load("gfx/"..vv..".png");
      local y = 0;
      if vv == "panel" or vv == "panel_broken" then
        y = 60;
      elseif vv == "door1" or vv == "door1_open" then
        y = 35;
      elseif vv == "door2" or vv == "door3" or vv == "door4" or vv == "door2_open" then
        y = 60;
      elseif vv == "window" or vv == "window2" then
        y = 62;
      elseif vv == "toolbox" then
        y = 171;
      elseif vv == "crio" or vv == "crio_blood" then
        y = 45;
      elseif vv == "robot" or vv == "robot_nohand" or vv == "robot_nohand_blaster" or vv == "robot_cargo" then
        y = 75;
      elseif vv == "box" then
        y = 145;
      elseif vv == "shelf" then
        y = 60;
      elseif vv == "box2" then
        y = 50;
      elseif vv == "rat" then
        y = 135;
      elseif vv == "rat_dead" then
        y = 100;
      elseif vv == "box3" then
        y = 110;
      elseif vv == "blood" then
        y = 107;
      elseif vv == "shaft" or vv == "shaft_open" then
        y = 55;
      elseif vv == "mutant" then
        y = 28;
      elseif vv == "med" then
        y = 60;
      elseif vv == "zombi" then
        y = 75;
      elseif vv == "device" then
        y = 65;
      elseif vv == "bfg" then
        y = 40;
      elseif vv == "hole" then
        y = 65;
      elseif vv == "hole2" then
        y = 35;
      elseif vv == "washer" then
        y = 55;
      elseif vv == "toilet" then
        y = 90;
      elseif vv == "communicator" then
        y = 80;
      elseif vv == "table" then
        y = 110;
      elseif vv == "zombi_dead" then
        y = 145;
      elseif vv == "blaster" or vv == "knife" then
        y = 40;
      elseif vv == "vase_flower" or vv == "vase" then
        y = 70;
      elseif vv == "repair" or vv == "repair_broken" or vv == "repair_meteor" then
        y = 95;
      end
      sprite.compose(spr, game.cache, tc(v[2],s), y);
      sprite.free(spr);
    end
  end
  return game.cache;
end

function exec_(s)
  return function(this)
    return exec(s,this);
  end
end

function apply(c,this)
  local f = assert(loadstring("return function(s) return ("..c.."); end"))();
  return f(this);
end

local oob = obj;
function tc(f,s)
if type(f) == "function" then return tc(f(s),s) else return f end
end
function obj(t)
local d = t.dsc;
t.dsc = function(s) if s.cnd == nil or s:cnd() then return tc(d,s) end end
return oob(t);
end

function gamefile_(fl)
  return function()
    gamefile(fl, true);
  end
end